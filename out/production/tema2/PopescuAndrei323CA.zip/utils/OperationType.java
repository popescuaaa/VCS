package utils;

public enum OperationType {
    // TODO add vcs commands
    CAT,
    CHANGEDIR,
    LIST,
    MAKEDIR,
    REMOVE,
    TOUCH,
    WRITETOFILE,
    PRINT,
    VCS_INVALID_OPERATION,
    FILESYSTEM_INVALID_OPERATION,
    STATUS, // printeaza ce e in staging
    BRANCH,
    COMMIT,
    CHECKOUT,
    LOG,
    ROLLBACK


}
