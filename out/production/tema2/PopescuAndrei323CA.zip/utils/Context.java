package utils;


import vcs.Branch;
import vcs.Commit;
import vcs.Vcs;

import java.util.ArrayList;

public final class Context {
    private static final Integer BRANCHES_INITIAL_NUMBER = 10;
    private static final Integer COMMANDS_INITIAL_NUMBER = 10;

    private Vcs vcs;
    private static Context instance = null;
    private InputReader inputReader;
    private OutputWriter outputWriter;
    private ArrayList<String> stagedChanges = new ArrayList<>(COMMANDS_INITIAL_NUMBER);

    private ArrayList<Branch> branches =  new ArrayList<>(BRANCHES_INITIAL_NUMBER);
    private Branch currentBranch;

    /**
     * Context constructor.
     */
    private Context() {
    }

    /**
     *
     * @return Staged changes
     */
    public ArrayList<String> getStagedChanges() {
        return  stagedChanges;
    }

    /**
     * Gets the instance.
     *
     * @return the instance
     */
    public static Context getInstance() {
        if (instance == null) {
            instance = new Context();
        }

        return instance;
    }

    /**
     * Initialise the vcs.
     *
     * @param input  the input file
     * @param output the output file
     */
    public void init(String input, String output) {

        inputReader = new InputReader(input);
        outputWriter = new OutputWriter(output);
        vcs = new Vcs(outputWriter);
        currentBranch = new Branch("master");
        ArrayList<String> fCommitMsg = new ArrayList<>(10);
        fCommitMsg.add("First");
        fCommitMsg.add("commit");
        this.vcs.init();
        Commit firstCommit = new Commit(fCommitMsg, vcs.getActiveSnapshot());
        currentBranch.addCommit(firstCommit); // just for master
        branches.add(currentBranch);
    }

    /**
     * Runs the context.
     */
    public void run() {
        String operationString = "";
        AbstractOperation operation;
        OperationParser parser = new OperationParser();
        int exitCode;
        boolean wasError;



        while (true) {
            operationString = this.inputReader.readLine();
            if (operationString == null || operationString.isEmpty()) {
                continue;
            }
            if (operationString.equals("exit")) {
                return;
            }

            operation = parser.parseOperation(operationString);
            exitCode = operation.accept(vcs);
            wasError = ErrorCodeManager.getInstance().checkExitCode(outputWriter, exitCode);

            if (!wasError && this.isTrackable(operation)) {
                stagedChanges.add(operationString);
            }
        }
    }

    /**
     * Specifies if an operation is vcs trackable or not.
     * You can use it when you implement rollback/checkout -c functionalities.
     * @param abstractOperation the operation
     * @return whether it's trackable or not
     */
    private boolean isTrackable(AbstractOperation abstractOperation) {
        boolean result;
        // comenzi valide de sistem care trebuie puse in staging
        switch (abstractOperation.type) {
            case CHANGEDIR:
            case MAKEDIR:
            case REMOVE:
            case TOUCH:
            case WRITETOFILE:
                result = true;
                break;
            default:
                result = false;
        }

        return result;
    }

    /**
     *
     * @param newBranch
     */
    public void changeBranch(final Branch newBranch) {
        currentBranch = newBranch;
    }

    /**
     *
     * @return currentBranch
     */
    public Branch getCurrentBranch() {
        return currentBranch;
    }

    /**
     *
     * @return branches
     */
    public ArrayList<Branch> getBranches() {
        return branches;
    }

    /**
     *
     * @param branch
     */
    public void addNewBranch(final Branch branch) {
        branches.add(branch);
    }
}
